<html>
    <head>
        <title>Ejercicio 02_05</title>
    </head>
    <body>
        <form action="ejercicio02_05.php">
            <p>Nombre: <input type="text" name="nombre"></p>
            <p>Primer apellido: <input type="text" name="apellido1"></p>
            <p>Segundo apellido: <input type="text" name="apellido2"></p>
            <p>Nombre de usuario: <input type="text" name="username"></p>
            <p>Número de identificación (DNI o NIE): <input type="text" name="dni"></p>
            <p>Teléfono: <input type="text" name="telefono"></p>
            
            <p><input type="submit" value="Validar"></p>
        </form>

        <?php

        ?>
    </body>
<html>